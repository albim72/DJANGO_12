from django.db import models

class DataModel(models.Model):
    name = models.CharField(max_length=200)
    department = models.CharField(max_length=300)
    age = models.IntegerField()

    def __str__(self)->str:
        return self.name