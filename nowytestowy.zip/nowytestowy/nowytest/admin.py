from django.contrib import admin
from nowytest.models import Post

admin.site.register(Post)

# Register your models here.
