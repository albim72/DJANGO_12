from django.db import models

class Status(models.TextChoices):
    UNSTARTED = 'u','jeszcze nie jest wykonywane'
    ONGOING = 'o','w trakcie wykonania'
    FINISHED = 'f','zakończone'

class Task(models.Model):
    name = models.CharField(verbose_name="Task name",max_length=65, unique=True)
    status = models.CharField(verbose_name="Task status", max_length=1,choices=Status.choices)

    def __str__(self):
        return self.name

