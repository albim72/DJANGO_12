from django.apps import AppConfig


class FromFormToTableConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'from_form_to_table'
