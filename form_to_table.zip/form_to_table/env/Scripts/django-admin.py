#!C:\BOOTCAMP_PYTHON_PROJEKTY\STRONY_WWW\PROJEKTY_DJANGO\form_to_table\form_to_table\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
