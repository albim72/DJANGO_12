"""
Package for simpleapp.
"""
