from django.test import TestCase

from datetime import date,timedelta
from django.test import TestCase
from django.urls import reverse
from todo.models import ToDoItem

def create_todo(todo_text,days):
    return ToDoItem.objects.create(text=todo_text,due_date=date.today() + timedelta(days=days))

class AllToDosViewTest(TestCase):
    def test_today(self):
        todo = create_todo("to będzie zrobione dziś",0)
        response = self.client.get(reverse("index"))
        self.assertQuerySetEqual(
            response.context["todoitem_list"],
            [todo]
        )


    def test_last_week(self):
        todo = create_todo("termin wykonania upłynął",-7)
        response = self.client.get(reverse("index"))
        self.assertQuerySetEqual(
            response.context["todoitem_list"],
            [todo]
        )

    def test_next_week(self):
        todo = create_todo("jest jeszcze czas na wykonanie...",7)
        response = self.client.get(reverse("index"))
        self.assertQuerySetEqual(
            response.context["todoitem_list"],
            [todo]
        )
