from django import forms
from .models import Snippet
from django.core.validators import RegexValidator
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout,Submit

class NameWidget(forms.MultiWidget):

    def __init__(self, attrs=None):
        super().__init__([
            forms.TextInput(),
            forms.TextInput()
        ],attrs)

    def decompress(self, value):
        if value:
            return value.split(' ')
        return ['', '']

class NameField(forms.MultiValueField):
    widget = NameWidget

    def __init__(self, *args, **kwargs):

        fields = (
            forms.CharField(validators=[
                RegexValidator(f'[a-zA-z]+','Podaj pierwsze imię (tylko litery)')
            ]),
            forms.CharField(validators=[
                RegexValidator(f'[a-zA-z]+', 'Podaj drugie imię (tylko litery)')
            ]),
        )
        super().__init__(fields, *args, **kwargs)

    def compress(self, data_list):
        return f'{data_list[0]} {data_list[1]}'


class ContactForm(forms.Form):
    name = NameField()
    email = forms.EmailField(label='E-Mail')
    category = forms.ChoiceField(choices=[('pytanie','Pytanie'),('inne','Inne')])
    subject = forms.CharField(required=False)
    body = forms.CharField(widget=forms.Textarea)

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.helper = FormHelper
        self.helper.form_method = 'post'

        self.helper.layout = Layout(
            'name',
            'email',
            'category',
            'subject',
            'body',
            Submit('submit','Wyślij',css_class='btn-success')
        )

class SnippetForm(forms.ModelForm):
    class Meta:
        model = Snippet
        fields = ('name','body')








